#!/bin/bash

svn --force export http://svn.scipy.org/svn/scipy/trunk/scipy/sparse/sparsetools/bsr.h
svn --force export http://svn.scipy.org/svn/scipy/trunk/scipy/sparse/sparsetools/coo.h
svn --force export http://svn.scipy.org/svn/scipy/trunk/scipy/sparse/sparsetools/csc.h
svn --force export http://svn.scipy.org/svn/scipy/trunk/scipy/sparse/sparsetools/csr.h
svn --force export http://svn.scipy.org/svn/scipy/trunk/scipy/sparse/sparsetools/dense.h
svn --force export http://svn.scipy.org/svn/scipy/trunk/scipy/sparse/sparsetools/dia.h
svn --force export http://svn.scipy.org/svn/scipy/trunk/scipy/sparse/sparsetools/fixed_size.h
svn --force export http://svn.scipy.org/svn/scipy/trunk/scipy/sparse/sparsetools/scratch.h

